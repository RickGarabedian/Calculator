// Wait for the DOM to fully load before running scripts
document.addEventListener('DOMContentLoaded', () => {
    const display = document.getElementById('display');
    const buttonsContainer = document.querySelector('.calculator-buttons');

    // Storing the input
    let currentInput = '';

    // Attach event listener for button clicks
    buttonsContainer.addEventListener('click', handleButtonClick);

    /**
     * Handles click events for the calculator buttons.
     * @param {Event} event - The click event on a button.
     */
    function handleButtonClick(event) {
        const target = event.target;
        if (target.tagName.toLowerCase() !== 'button') return;

        // Retrieve the button's value from data attribute
        const buttonValue = target.getAttribute('data-value');

        // Process the button input:
        // - Update the display with the pressed value.
        // - Build the arithmetic expression.
        // - Handle special buttons (e.g., clear, equals).

        // Example: (Uncommented the example)
         if (buttonValue === 'clear') {
           clearDisplay();
         } else if (buttonValue === '=') {
           computeResult();
         } else {
           updateDisplay(buttonValue);
         }
    }

    /**
     * Updates the display area with new input.
     * @param {string} value - The value to add to the display.
     */
    function updateDisplay(value) {
        // TODO: Update the calculator's display area

        // Prevent leading zeroes (except for decimal point)
        if (currentInput === '0' && value !== '.') {
            currentInput = value;
        } else {
            currentInput += value;
        }
        display.textContent = currentInput;
}

    /**
     * Computes the result of the arithmetic expression.
     */
    function computeResult() {
        // TODO: Evaluate the expression built from button inputs
        try {
            // Since Java doesn't understand the "×" and the "÷" sign, I had to replace them with "*" and "/"
            // THe result is computed automatically. If the input was  "5*2", the function will return 5*2
            currentInput = new Function('return ' + currentInput.replace('÷', '/').replace('×', '*'))();

            // After currentInput is calculated, we pass it to the textContent and update the display.
            display.textContent = currentInput;
            
             // Add the flash effect
        display.classList.add('text-flash');

        // Remove the flash effect after animation ends
        setTimeout(() => {
            display.classList.remove('text-flash');
        }, 300);
        } catch (error) {
            // This will only occur if there is an arithmatic error that Java can't solve.
            display.textContent = 'Error';
            // Resets currentInput
            currentInput = '';
        }
    }

    /**
     * Clears the display and resets stored values.
     */
    function clearDisplay() {
        // TODO: Clear the current calculation and reset the display
        currentInput = '';
        display.textContent = '0';
    }
})